package com.example.binarycalc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    EditText input, output;
    Button submit, reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Calling the EditText by id which we gave in xml file
        input = (EditText) findViewById(R.id.deci);
        output = (EditText) findViewById(R.id.ans);

        submit = (Button) findViewById(R.id.bin);

        // It is set so that when the user clicks
        // on submit button, the data
        // gets send in the function created below
        // which will convert it and then
        // show the answer to the user in the output
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String string = input.getText().toString();

                // Here, we are parsing a string method
                // argument into an integer object
                int n = Integer.parseInt(string);
                int[] binaryNum = new int[1000];
                String outString="";
                // counter for binary array
                int i = 0;
                while (n > 0)
                {
                    // storing remainder in binary array
                    binaryNum[i] = n % 2;
                    n = n / 2;
                    i++;
                }

                // printing binary array in reverse order
                for (int j = i - 1; j >= 0; j--)
                    //System.out.print(binaryNum[j]);
                    outString+=binaryNum[j];

            // Converts and stores it in the form of string
                String binary = outString;//Integer.toBinaryString(n);

                // It will show the output in the
                // second edit text that we created
                output.setText(binary);

            }
        });

        // Here, we will define a function which
        // will clear the whole text and reset it
//        reset = (Button) findViewById(R.id.reset);
//        reset.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                input.setText("");
//                output.setText("");
//            }
//        });

    }
}